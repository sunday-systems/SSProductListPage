<?php

namespace Plugin\SSProductListPage\Entity;

use Doctrine\ORM\Mapping as ORM;
use Eccube\Annotation as Eccube;

/**
 * @Eccube\EntityExtension("Eccube\Entity\Layout")
 */
trait LayoutTrait {
    /**
     * @var \Doctrine\Common\Collections\Collection
     *
     * @ORM\OneToMany(targetEntity="\Plugin\SSProductListPage\Entity\CategoryLayout", mappedBy="Layout", cascade={"persist","remove"})
     * @ORM\OrderBy({"sort_no" = "ASC"})
     */
    private $CategoryLayouts;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->BlockPositions = new \Doctrine\Common\Collections\ArrayCollection();
        $this->PageLayouts = new \Doctrine\Common\Collections\ArrayCollection();
        $this->CategoryLayouts = new \Doctrine\Common\Collections\ArrayCollection();
    }

    public function addCategoryLayout(CategoryLayout $CategoryLayout)
    {
        $this->CategoryLayouts[] = $CategoryLayout;

        return $this;
    }

    public function removeCategoryLayout(CategoryLayout $CategoryLayout)
    {
        $this->CategoryLayouts->removeElement($CategoryLayout);
    }

    /**
     * Get CategoryLayoutLayouts
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getCategoryLayouts()
    {
        return $this->CategoryLayouts;
    }

    /**
     * Check layout can delete or not
     *
     * @return boolean
     */
    public function isDeletable()
    {
        if (!$this->getPageLayouts()->isEmpty()) {
            return false;
        }

        if (!$this->getCategoryLayouts()->isEmpty()) {
            return false;
        }

        return true;
    }
}